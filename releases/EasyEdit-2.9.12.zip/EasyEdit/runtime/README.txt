ضع ffmpeg.exe هنا لو الـ installer مقدرش ينزله (اختياري لو ffmpeg موجود على الجهاز).
