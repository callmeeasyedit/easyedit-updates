/* EasyEdit KeyAuth client.
 * Uses KeyAuth's signed-response protocol; never includes a Seller Key.
 * Signature format follows the official KeyAuth JavaScript example:
 * https://github.com/KeyAuth/KeyAuth-JavaScript-Example
 */
(function (G) {
  'use strict';
  var S = G.Sys, req = S && S.req, fs, path, https, crypto, Buffer;
  try { fs = req('fs'); path = req('path'); https = req('https'); crypto = req('crypto'); Buffer = req('buffer').Buffer; } catch (e) {}
  var ext = S && S.extDir ? S.extDir() : '';
  function readConfig() { try { return JSON.parse(fs.readFileSync(path.join(ext, 'keyauth.json'), 'utf8')); } catch (e) { return {}; } }
  var cfg = readConfig(), api = String(cfg.apiUrl || 'https://keyauth.win/api/1.3/');
  var PUBLIC_KEY = '5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b';
  var state = { status: 'setup', ok: false, reason: 'subscribe', message: 'أدخل مفتاح EasyEdit للبدء.' }, session = '', initialized = false, hwid = '', lastVerifiedAt = 0;
  var store = G.K && G.K.store ? G.K.store('easyedit_auth_') : null;
  var keyObject = null;
  try { keyObject = crypto.createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(PUBLIC_KEY, 'hex')]), format: 'der', type: 'spki' }); } catch (e) {}
  function configured() { return !!(cfg && cfg.name && cfg.ownerid && !/^CHANGE_ME/i.test(cfg.name) && !/^CHANGE_ME/i.test(cfg.ownerid)); }
  function verify(raw, headers) {
    var signature = headers['x-signature-ed25519'], timestamp = headers['x-signature-timestamp'];
    if (!signature || !timestamp || !keyObject || !crypto) throw new Error('تعذّر التحقق من توقيع خادم الترخيص.');
    var seconds = Number(timestamp), skew = Math.abs(Date.now() / 1000 - seconds);
    if (!isFinite(seconds) || skew > 120) throw new Error('ساعة الجهاز غير متزامنة مع خادم الترخيص.');
    var sigText = String(signature).trim(), sigBytes = /^[0-9a-fA-F]{128}$/.test(sigText) ? Buffer.from(sigText, 'hex') : Buffer.from(sigText, 'base64');
    var message = Buffer.from(String(timestamp) + String(raw), 'utf8');
    if (!crypto.verify(null, message, keyObject, sigBytes)) throw new Error('ردّ خادم الترخيص غير موثوق.');
    try { return JSON.parse(raw); } catch (e) { throw new Error('ردّ KeyAuth الموقّع ليس JSON صالحًا.'); }
  }
  function post(data) {
    return new Promise(function (resolve, reject) {
      if (!https || !Buffer) return reject(new Error('مكوّن اتصال الترخيص غير متاح.'));
      var u; try { u = new URL(api); } catch (e) { return reject(new Error('عنوان KeyAuth غير صالح.')); }
      if (u.protocol !== 'https:') return reject(new Error('اتصال KeyAuth يجب أن يستخدم HTTPS.'));
      var query = Object.keys(data).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(String(data[k])); }).join('&');
      var requestPath = (u.pathname || '/') + (u.search ? u.search + '&' : '?') + query;
      var q = https.request({ protocol: 'https:', hostname: u.hostname, port: u.port || 443, path: requestPath, method: 'GET', timeout: 15000 }, function (res) {
        var chunks = [], size = 0;
        res.on('data', function (d) { size += d.length; if (size > 1024 * 1024) { q.destroy(new Error('ردّ KeyAuth أكبر من المتوقع.')); return; } chunks.push(d); });
        res.on('end', function () {
          var raw = Buffer.concat(chunks).toString('utf8'), parsed;
          try { parsed = JSON.parse(raw); } catch (e) {
            var preview = raw.replace(/\s+/g, ' ').slice(0, 100);
            return reject(new Error('خادم KeyAuth ردّ بنص غير JSON (HTTP ' + res.statusCode + '): ' + (preview || 'رد فارغ')));
          }
          try { resolve(verify(raw, res.headers)); } catch (e) { reject(e); }
        });
      });
      q.on('timeout', function () { q.destroy(new Error('انتهت مهلة الاتصال بخادم KeyAuth.')); });
      q.on('error', reject); q.end();
    });
  }
  function base(type) { return { type: type, name: cfg.name, ownerid: cfg.ownerid, ver: String(cfg.version || '1.0.0') }; }
  function init() {
    if (initialized && session) return Promise.resolve(true);
    if (!configured()) return Promise.reject(new Error('إعدادات KeyAuth غير مكتملة: يلزم اسم التطبيق وOwner ID.'));
    return post(base('init')).then(function (r) { if (!r.success || !r.sessionid) throw new Error(r.message || 'فشل تهيئة KeyAuth.'); session = r.sessionid; initialized = true; return true; });
  }
  function activate(key) {
    key = String(key || '').trim();
    if (!key) return Promise.reject(new Error('اكتب مفتاح التفعيل أولًا.'));
    state = { status: 'checking', ok: false, reason: 'subscribe', message: 'جارٍ التحقق من المفتاح…' };
    return init().then(function () {
      var d = base('license'); d.sessionid = session; d.key = key; d.hwid = hwid;
      return post(d);
    }).then(function (r) {
      if (!r.success) throw new Error(r.message || 'المفتاح غير صالح أو منتهي.');
      if (store) store.set('key', key);
      var info = r.info || {}, subs = info.subscriptions || [], sub = subs[0] || {};
      lastVerifiedAt = Date.now();
      state = { status: 'active', ok: true, reason: '', message: '', username: info.username || '', subscription: sub.subscription || '', expiry: Number(sub.expiry || info.expires || 0), key: key };
      return state;
    }).catch(function (e) { state = { status: 'inactive', ok: false, reason: 'subscribe', message: e.message || 'تعذّر تفعيل المفتاح.' }; throw e; });
  }
  function start(device, savedKey) {
    hwid = String(device || '');
    if (!configured()) { state = { status: 'setup', ok: false, reason: 'subscribe', message: 'ترخيص EasyEdit غير مهيأ بعد.' }; return Promise.resolve(state); }
    state = { status: 'checking', ok: false, reason: 'subscribe', message: 'جارٍ الاتصال بخادم الترخيص…' };
    return init().then(function () { var k = savedKey || (store && store.get('key', '')) || ''; return k ? activate(k) : (state = { status: 'inactive', ok: false, reason: 'subscribe', message: 'أدخل مفتاح EasyEdit للمتابعة.' }); }).catch(function (e) { state = { status: 'inactive', ok: false, reason: 'offline', message: e.message || 'تعذّر الوصول إلى خادم الترخيص.' }; return state; });
  }
  function check() {
    if ((!initialized || !session) && store && store.get('key', '')) return start(hwid, store.get('key', ''));
    if (!state.ok) {
      if ((state.reason === 'offline' || state.reason === 'session') && store && store.get('key', '')) return activate(store.get('key', ''));
      return Promise.resolve(state);
    }
    if (!initialized || !session) return Promise.resolve(state);
    var d = base('check'); d.sessionid = session;
    return post(d).then(function (r) {
      if (!r.success) { initialized = false; session = ''; state = { status: 'inactive', ok: false, reason: 'session', message: r.message || 'انتهت جلسة الترخيص.' }; return state; }
      lastVerifiedAt = Date.now();
      return state;
    }).catch(function () {
      if (Date.now() - lastVerifiedAt > 10 * 60 * 1000) state = { status: 'inactive', ok: false, reason: 'offline', message: 'تعذّر تجديد التحقق من الترخيص. اتصل بالإنترنت وحاول مجددًا.' };
      return state;
    });
  }
  G.KeyAuth = { configured: configured, start: start, activate: activate, check: check, state: function () { return Object.assign({}, state); }, config: cfg };
})(window);
