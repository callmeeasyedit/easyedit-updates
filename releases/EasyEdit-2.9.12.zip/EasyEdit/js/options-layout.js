/* EasyEdit — focused option workspace shared by every tool. */
(function (G) {
  'use strict';
  var D = G.document, roots = [], timers = [];
  function allSections(tab) {
    return Array.prototype.filter.call(tab.children, function (el) {
      return el.classList && el.classList.contains('sec') && !el.classList.contains('hide');
    });
  }
  function same(a, b) {
    if (!a || a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
    return true;
  }
  function activeIndex(sections, tabId) {
    var saved = -1;
    try { saved = parseInt(G.localStorage.getItem('easyedit_options_' + tabId), 10); } catch (e) {}
    if (saved >= 0 && saved < sections.length) return saved;
    for (var i = 0; i < sections.length; i++) if (!sections[i].classList.contains('closed')) return i;
    return 0;
  }
  function enhance(tab) {
    if (!tab || !tab.id || !tab.classList.contains('tab')) return;
    var sections = allSections(tab);
    if (!sections.length) return;
    var prev = tab.__easyEditOptionSections;
    if (same(prev, sections) && tab.querySelector(':scope > .opt-workspace')) return;
    var old = tab.querySelector(':scope > .opt-workspace');
    var pick = old && old.__activeIndex;
    if (typeof pick !== 'number') pick = activeIndex(sections, tab.id);
    if (old) old.remove();
    tab.__easyEditOptionSections = sections.slice();

    var workspace = D.createElement('section');
    workspace.className = 'opt-workspace';
    workspace.setAttribute('aria-label', 'تنظيم خيارات الأداة');
    var title = D.createElement('div'); title.className = 'opt-workspace-title';
    title.innerHTML = '<span>إعدادات الأداة</span><small></small>';
    var count = title.querySelector('small'); count.textContent = sections.length + ' أقسام';
    var list = D.createElement('div'); list.className = 'opt-switcher'; list.setAttribute('role', 'tablist');
    list.setAttribute('aria-label', 'أقسام الإعدادات');
    var buttons = [];

    function activate(index, save) {
      if (index < 0 || index >= sections.length) return;
      workspace.__activeIndex = index;
      sections.forEach(function (sec, i) {
        sec.classList.toggle('opt-current', i === index);
        sec.classList.toggle('opt-dormant', i !== index);
        if (i === index) sec.classList.remove('closed'); else sec.classList.add('closed');
      });
      buttons.forEach(function (button, i) {
        var on = i === index;
        button.classList.toggle('on', on);
        button.setAttribute('aria-selected', on ? 'true' : 'false');
        button.setAttribute('tabindex', on ? '0' : '-1');
      });
      if (save) try { G.localStorage.setItem('easyedit_options_' + tab.id, String(index)); } catch (e) {}
      setTimeout(function () { try { G.dispatchEvent(new Event('resize')); } catch (e) {} }, 30);
    }

    sections.forEach(function (sec, i) {
      var heading = sec.querySelector(':scope > .sh');
      var label = heading ? heading.textContent.trim() : 'قسم ' + (i + 1);
      var b = D.createElement('button');
      b.type = 'button'; b.className = 'opt-tab'; b.setAttribute('role', 'tab');
      b.setAttribute('aria-label', label); b.textContent = label;
      b.addEventListener('click', function () { activate(i, true); });
      b.addEventListener('keydown', function (e) {
        if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
        e.preventDefault(); var n = (i + (e.key === 'ArrowRight' ? 1 : -1) + buttons.length) % buttons.length;
        buttons[n].focus(); activate(n, true);
      });
      list.appendChild(b); buttons.push(b);
      Array.prototype.forEach.call(sec.querySelectorAll('.sb > *'), function (item) {
        if (item.matches && item.matches('.sld,.seg,.crow,.tiles,.strip,.adds,.search,.caplist,.looks,.flist,.kflist,.report,.lib,.pgrid,.fxgrid,.hint,.chips,.folders,.sbar,.notice,.tk,.prog')) item.classList.add('opt-wide');
        if (item.classList && item.classList.contains('field') && item.querySelector('.seg,.tg')) item.classList.add('opt-wide');
      });
    });
    workspace.appendChild(title); workspace.appendChild(list);
    tab.insertBefore(workspace, sections[0]);
    activate(pick, false);
  }
  function schedule(tab) {
    var i = roots.indexOf(tab); if (i < 0) return;
    clearTimeout(timers[i]); timers[i] = setTimeout(function () { enhance(tab); }, 40);
  }
  function watch(tab) {
    if (roots.indexOf(tab) >= 0) return;
    roots.push(tab); timers.push(0);
    if (G.MutationObserver) {
      var observer = new MutationObserver(function () { schedule(tab); });
      observer.observe(tab, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    }
    enhance(tab);
  }
  function current() {
    var active = D.querySelector('.tab:not(.hide)');
    if (active) watch(active);
  }
  function init() {
    Array.prototype.forEach.call(D.querySelectorAll('.tab'), watch);
    if (G.Tabs && typeof G.Tabs.show === 'function' && !G.Tabs.show.__easyEditWrapped) {
      var original = G.Tabs.show;
      var wrapped = function (id) { var result = original.apply(this, arguments); setTimeout(current, 25); return result; };
      wrapped.__easyEditWrapped = true; G.Tabs.show = wrapped;
    }
    if (D.getElementById('tabs')) D.getElementById('tabs').addEventListener('click', function () { setTimeout(current, 25); });
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', init); else init();
})(window);
