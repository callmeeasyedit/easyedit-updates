/* Home screen copy for English mode. Tool IDs remain the same as the live modules. */
(function (G) {
  G.EasyEditHomeEn = {
    categories: {
      vid: 'Cut & Edit Tools',
      aud: 'Effects & Enhancements',
      gfx: 'Text & Graphics',
      prj: 'Utilities & Others'
    },
    tools: {
      carousel: { name: '3D Carousel', description: 'Create animated 3D carousels from photos and videos' },
      text: { name: 'Text', description: 'Ready-made text styles and animation' },
      fx: { name: 'Text Effects', description: 'Text entrance and exit animations' },
      path: { name: 'Text on Path', description: 'Place text along a path you draw' },
      glass: { name: 'Glass Shapes', description: 'Create transparent glass shapes' },
      icons: { name: '3D Icons', description: 'Browse a library of 3D icons' },
      obj3d: { name: '3D Objects', description: 'Tech, medical, business, holograms, maps and GLB' },
      social: { name: 'Social', description: 'Subscribe, like, comment, notifications and follow' },
      lower: { name: 'Lower Thirds', description: 'Add a name and title below the speaker' },
      backgrounds: { name: 'Backgrounds', description: 'Ready-made animated backgrounds' },
      lines: { name: 'Animated Lines', description: 'Self-drawing lines and arrows' },
      insert: { name: 'Insert', description: 'Pinned images, frames and video circles' },
      counter: { name: 'Number Counter', description: 'Animate a count between two numbers' },
      filters: { name: 'Color & Filters', description: 'Cinematic filters and LUTs' },
      trans: { name: 'Transitions', description: 'Add transitions between clips' },
      ramp: { name: 'Speed Ramp', description: 'Smoothly speed up or slow down clips' },
      zoom: { name: 'Auto Zoom', description: 'Automatically zoom to speech' },
      track: { name: 'Tracking', description: 'Track a point or surface in your video' },
      curves: { name: 'Keyframe Curves', description: 'Ready-made motion curves' },
      download: { name: 'Web Download', description: 'Download a video or a segment from websites' },
      caption: { name: 'Captions', description: 'Automatic Arabic and English captions' },
      cut: { name: 'Silence Cutter', description: 'Automatically remove pauses' },
      clean: { name: 'Audio Cleaner', description: 'Reduce noise and clarify speech' },
      sfx: { name: 'Sound Effects', description: 'Sound effects library from your folders' },
      viz: { name: 'Audio Visualizer', description: 'Audio bars and waveforms that react to sound' },
      items: { name: 'Premiere Items', description: 'Create adjustment layers, solids and screenshots' },
      organize: { name: 'Organize Project', description: 'Sort project items into bins' },
      safe: { name: 'Safe Zones', description: 'Safe guides for TikTok, Reels and YouTube' },
      support: { name: 'Help & Support', description: 'Get help and check your setup' },
      admin: { name: 'Control Center', description: 'Owner panel and release statistics' }
    }
  };
})(window);
