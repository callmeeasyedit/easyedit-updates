/* Responsive navigation rail inspired by the EasyEdit reference. Existing tool actions stay bound to Tabs. */
(function (G) {
  'use strict';
  var D = G.document;
  var CATS = [
    { id: 'vid', ar: 'قص ومونتاج', en: 'Cut & Edit Tools', icon: '✂' },
    { id: 'aud', ar: 'مؤثرات وتحسينات', en: 'Effects & Enhancements', icon: '✦' },
    { id: 'gfx', ar: 'نصوص وجرافيك', en: 'Text & Graphics', icon: 'T' },
    { id: 'prj', ar: 'أدوات مساعدة', en: 'Utilities & Others', icon: '▦' }
  ];
  function text(ar, en) { return G.I18N && G.I18N.lang() === 'en' ? en : ar; }
  function makeNav() {
    if (D.querySelector('.ref-sidebar')) return D.querySelector('.ref-sidebar');
    var side = D.createElement('aside'); side.className = 'ref-sidebar'; side.setAttribute('aria-label', text('التنقل', 'Navigation'));
    side.innerHTML = '<div class="ref-side-brand"><img src="icons/icon-128.png" alt=""><span><b>EasyEdit</b><small>Premiere Pro</small></span></div><div class="ref-side-label">' + text('مساحة العمل', 'WORKSPACE') + '</div><nav class="ref-side-nav"></nav><div class="ref-side-bottom"><div class="ref-side-glow"></div><b>EasyEdit</b><span>' + text('ارتقِ بمونتاجك', 'Elevate your editing') + '</span><small>' + text('أدواتك الإبداعية في مكان واحد', 'Your creative tools in one place') + '</small></div>';
    var nav = side.querySelector('.ref-side-nav');
    var home = D.createElement('button'); home.type = 'button'; home.className = 'ref-nav-item'; home.setAttribute('data-nav', 'home'); home.innerHTML = '<i>⌂</i><span>' + text('الرئيسية', 'Home') + '</span>';
    home.addEventListener('click', function () { if (G.Tabs) G.Tabs.home(); sync(); }); nav.appendChild(home);
    CATS.forEach(function (c) {
      var b = D.createElement('button'); b.type = 'button'; b.className = 'ref-nav-item'; b.setAttribute('data-nav', c.id);
      b.innerHTML = '<i>' + c.icon + '</i><span>' + text(c.ar, c.en) + '</span>';
      b.addEventListener('click', function () {
        var first = D.querySelector('#tools button[data-cat="' + c.id + '"]');
        if (first && G.Tabs) G.Tabs.show(first.getAttribute('data-tab'));
        sync();
      });
      nav.appendChild(b);
    });
    var settings = D.createElement('button'); settings.type = 'button'; settings.className = 'ref-nav-item ref-nav-secondary'; settings.setAttribute('data-nav', 'settings');
    settings.innerHTML = '<i>⚙</i><span>' + text('ألوان الواجهة', 'Appearance') + '</span>';
    settings.addEventListener('click', function () { var t = D.querySelector('.theme-trigger'); if (t) t.click(); }); nav.appendChild(settings);
    var help = D.createElement('button'); help.type = 'button'; help.className = 'ref-nav-item ref-nav-secondary'; help.setAttribute('data-nav', 'support');
    help.innerHTML = '<i>?</i><span>' + text('الدعم', 'Help & Support') + '</span>';
    help.addEventListener('click', function () { if (G.Tabs) G.Tabs.show('support'); sync(); }); nav.appendChild(help);
    var header = D.getElementById('hdr');
    if (header && !header.querySelector('.update-trigger')) {
      var update = D.createElement('button'); update.type = 'button'; update.className = 'update-trigger';
      update.title = text('التحقق من التحديثات', 'Check for updates'); update.setAttribute('aria-label', update.title); update.innerHTML = '<span aria-hidden="true">↻</span>';
      update.addEventListener('click', function () { if (G.Updater) G.Updater.check(true); });
      var themeButton = header.querySelector('.theme-trigger'); header.insertBefore(update, themeButton || null);
    }
    D.body.insertBefore(side, D.body.firstChild);
    return side;
  }
  function dockLanguage() {
    var lang = D.querySelector('#home .hlang'), header = D.getElementById('hdr');
    if (!lang || !header || lang.parentNode === header) return;
    lang.classList.add('global-lang');
    var before = header.querySelector('.theme-trigger');
    header.insertBefore(lang, before || null);
  }
  function sync() {
    var side = D.querySelector('.ref-sidebar'); if (!side || !G.Tabs) return;
    var id = G.Tabs.current(), group = 'home';
    if (id) {
      var tool = D.querySelector('#tools button[data-tab="' + id + '"]');
      group = tool ? tool.getAttribute('data-cat') : id === 'support' ? 'support' : 'home';
    }
    Array.prototype.forEach.call(side.querySelectorAll('[data-nav]'), function (b) {
      var on = b.getAttribute('data-nav') === group;
      b.classList.toggle('active', on);
      if (on) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
  }
  function init() {
    makeNav(); dockLanguage(); sync();
    var home = D.getElementById('home');
    if (home && G.MutationObserver) new MutationObserver(function () { dockLanguage(); }).observe(home, { childList: true, subtree: true });
    if (D.getElementById('tools')) D.getElementById('tools').addEventListener('click', function () { setTimeout(sync, 20); });
    if (home) home.addEventListener('click', function () { setTimeout(sync, 20); });
    if (D.getElementById('cats')) D.getElementById('cats').addEventListener('click', function () { setTimeout(sync, 20); });
    if (G.Tabs && typeof G.Tabs.show === 'function' && !G.Tabs.show.__easyEditLayoutWrapped) {
      var original = G.Tabs.show;
      var wrapped = function () { var r = original.apply(this, arguments); setTimeout(sync, 25); return r; };
      wrapped.__easyEditLayoutWrapped = true; G.Tabs.show = wrapped;
    }
    G.addEventListener('focus', sync);
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', init); else init();
})(window);
