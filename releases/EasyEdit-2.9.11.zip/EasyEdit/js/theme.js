/* EasyEdit appearance controls */
(function (G) {
  'use strict';
  var D = G.document;
  var themes = [
    { id: 'violet', ar: 'بنفسجي', en: 'Violet', a: '#8e78e8', b: '#aa99ff', c: '#54d9c0', rgb: '142,120,232' },
    { id: 'blue', ar: 'أزرق', en: 'Blue', a: '#4f91e8', b: '#91bdff', c: '#61d9d1', rgb: '79,145,232' },
    { id: 'teal', ar: 'تركواز', en: 'Teal', a: '#168f84', b: '#55d6b7', c: '#9cdda0', rgb: '22,143,132' },
    { id: 'rose', ar: 'وردي', en: 'Rose', a: '#c65382', b: '#f08fba', c: '#f7c588', rgb: '198,83,130' },
    { id: 'amber', ar: 'ذهبي', en: 'Amber', a: '#b97f27', b: '#f1c267', c: '#eb7c68', rgb: '185,127,39' }
  ];
  var root = D.documentElement, button = null, panel = null;
  function apply(id) {
    var t = themes.filter(function (x) { return x.id === id; })[0] || themes[0];
    root.style.setProperty('--acc', t.a); root.style.setProperty('--acc2', t.b); root.style.setProperty('--acc3', t.c); root.style.setProperty('--brand-rgb', t.rgb);
    root.setAttribute('data-theme', t.id);
    try { G.localStorage.setItem('easyedit_theme', t.id); } catch (e) {}
    [].forEach.call(D.querySelectorAll('.theme-choice'), function (b) { var on = b.getAttribute('data-theme') === t.id; b.classList.toggle('on', on); b.setAttribute('aria-checked', on ? 'true' : 'false'); });
  }
  function close() { if (!panel || !button) return; panel.classList.add('hide'); button.setAttribute('aria-expanded', 'false'); }
  function place() {
    if (!button || !panel) return;
    var r = button.getBoundingClientRect(), w = panel.offsetWidth || 190;
    var left = Math.max(8, Math.min(G.innerWidth - w - 8, r.right - w));
    var top = Math.max(8, Math.min(G.innerHeight - 220, r.bottom + 8));
    panel.style.left = left + 'px'; panel.style.top = top + 'px';
  }
  function toggle(e) {
    if (e) { e.preventDefault(); e.stopPropagation(); }
    if (!panel) return;
    if (panel.classList.contains('hide')) { place(); panel.classList.remove('hide'); button.setAttribute('aria-expanded', 'true'); }
    else close();
  }
  function mount() {
    var header = D.getElementById('hdr'); if (!header || D.querySelector('.theme-trigger')) return;
    button = D.createElement('button'); button.type = 'button'; button.className = 'theme-trigger'; button.title = 'تغيير ألوان الواجهة'; button.setAttribute('aria-label', button.title); button.setAttribute('aria-haspopup', 'menu'); button.setAttribute('aria-expanded', 'false');
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3a9 9 0 1 0 0 18h1.2a2.1 2.1 0 0 0 1.3-3.7 1.4 1.4 0 0 1 .9-2.5H17a4 4 0 0 0 4-4c0-4.4-4-7.8-9-7.8Z"/><circle cx="7.5" cy="11" r=".9"/><circle cx="10" cy="7.5" r=".9"/><circle cx="15" cy="7.8" r=".9"/></svg>';
    panel = D.createElement('div'); panel.className = 'theme-pop hide'; panel.setAttribute('role', 'menu'); panel.setAttribute('aria-label', 'ألوان الواجهة');
    var label = D.createElement('div'); label.className = 'theme-title'; label.textContent = 'ألوان الواجهة'; panel.appendChild(label);
    themes.forEach(function (t) {
      var option = D.createElement('button'); option.type = 'button'; option.className = 'theme-choice'; option.setAttribute('data-theme', t.id); option.setAttribute('role', 'menuitemradio'); option.setAttribute('aria-checked', 'false');
      option.innerHTML = '<i style="--sw1:' + t.a + ';--sw2:' + t.b + ';--sw3:' + t.c + '"></i><span data-ar="' + t.ar + '" data-en="' + t.en + '">' + t.ar + '</span><b aria-hidden="true">✓</b>';
      option.addEventListener('click', function (e) { e.stopPropagation(); apply(t.id); option.setAttribute('aria-checked', 'true'); close(); }); panel.appendChild(option);
    });
    button.addEventListener('click', toggle); panel.addEventListener('click', function (e) { e.stopPropagation(); });
    D.addEventListener('click', close); D.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    G.addEventListener('resize', function () { if (panel && !panel.classList.contains('hide')) place(); });
    G.addEventListener('scroll', function () { if (panel && !panel.classList.contains('hide')) place(); }, true);
    header.appendChild(button); D.body.appendChild(panel);
    var saved = 'violet'; try { saved = G.localStorage.getItem('easyedit_theme') || saved; } catch (e) {} apply(saved);
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', mount); else mount();
  G.EasyEditTheme = { set: apply, open: function () { if (button && panel && panel.classList.contains('hide')) toggle(); } };
})(window);